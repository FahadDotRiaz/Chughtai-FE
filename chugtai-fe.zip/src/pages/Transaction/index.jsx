import Mir from "../MIR";

const Transactions = () => {
	return <Mir />;
};
export default Transactions;
