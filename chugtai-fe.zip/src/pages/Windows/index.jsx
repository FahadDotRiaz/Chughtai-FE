const Windows = () => {
	return <div>Windows</div>;
};
export default Windows;
