const File = () => {
	return <div>File</div>;
};
export default File;
