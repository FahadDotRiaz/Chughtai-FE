const Utilities = () => {
	return <div>Utilities</div>;
};
export default Utilities;
